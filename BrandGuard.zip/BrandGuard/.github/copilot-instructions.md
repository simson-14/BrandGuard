# BrandGuard Workspace Instructions

- Keep the frontend in `frontend/` (React, Vite, Tailwind) and the API in `backend/` (FastAPI, SQLAlchemy, SQLite).
- Keep analysis deterministic and rule-based. Every finding must point to a configured rule or a documented heuristic.
- Preserve review history and only set a document to `APPROVED` through an explicit approval action.
- Do not store credentials or submitted customer content in source control.
- Verify backend changes with `pytest` from `backend/` and frontend changes with `npm run build` from `frontend/`.